package brawns;

import javax.swing.JFrame;

public class Frame {

	public Frame(){
		// TODO Auto-generated method stub
		
		JFrame frame = new JFrame("Life Sim");
		Skeleton mainPanel= new Skeleton();
		frame.setSize(1200, 900);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.add(mainPanel);
		frame.setResizable(false);
		frame.setVisible(true);
	
	}

}
