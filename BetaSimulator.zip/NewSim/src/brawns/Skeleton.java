package brawns;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.JPanel;

public class Skeleton extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static ActivityPanel activity = new ActivityPanel();
	public Skeleton()
	{
		this.setLayout(new BorderLayout());
		
		AnimationPanel animate = new AnimationPanel();
		activity.setPreferredSize(new Dimension(250,900));
	
		this.setBackground(Color.green);
		this.add(activity,BorderLayout.EAST);
		this.add(animate,BorderLayout.CENTER);
		
	}
	
	
	
	
	
	public void paintComponent(Graphics g)
	{
		Graphics2D g2 = (Graphics2D)g;
		super.paintComponent(g2);
		
	}
	
	
	
	
	
	
}
