package brawns;

import java.awt.BorderLayout;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

/**
 * @author light
 *
 */
public class ActivityPanel extends JPanel {

	/**
	 * 
	 */
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 
	 */
	private static JTextArea status;
	/**
	 * 
	 */
	public ActivityPanel()
	{
		
	this.setLayout(new BorderLayout());
	 status = new JTextArea();
	 status.setText("");
	 JScrollPane scroll = new JScrollPane (status,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
	 this.add(scroll, BorderLayout.CENTER);
	 
	}
	
	/* (non-Javadoc)
	 * @see javax.swing.JComponent#paintComponent(java.awt.Graphics)
	 */
	public void paintComponent(Graphics g)
	{
		Graphics2D g2 = (Graphics2D)g;
		super.paintComponent(g2);
		
	}
	
	/**
	 * @param text
	 */
	public void addText(String text)
	{
		String prev = getText();
		prev = prev+"\n"+text;
		status.setText(prev);
		
	}

	/**
	 * @return
	 */
	private String getText() {
		// TODO Auto-generated method stub
		return status.getText();
	}
}
