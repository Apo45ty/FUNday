package brawns;

import java.util.ArrayList;
import java.util.Timer;

import brains.Person;
import brains.Setup;
import brains.Task;

/**
 * @author light
 *
 */
public class Starter {

	/**
	 * 
	 */
	public static ArrayList<Person> people = new ArrayList<Person>();
	/**
	 * 
	 */
	public static int tick;
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Setup set = new Setup();
		
		//Set up people(male)
		for(int i =0;i<set.getMale();i++)
		{
			Person temp = new Person();
			
			temp.setGender(0);
			people.add(temp);
			
			
		}
		
		//Set up people(female)
		for(int i =0;i<set.getMale();i++)
		{
			Person temp = new Person();
			temp.setGender(1);
			people.add(temp);
			
		}
		
		Timer timer = new Timer();
		Task timeTask = new Task();
		timer.schedule(timeTask, 0, 1000);
		Frame frame = new Frame();
	
	}

}
