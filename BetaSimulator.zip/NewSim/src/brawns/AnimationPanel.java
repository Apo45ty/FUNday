package brawns;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.Ellipse2D;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.JPanel;
import javax.swing.Timer;

import brains.Person;

/**
 * @author light
 *
 */
public class AnimationPanel extends JPanel {

	/**
	 * 
	 */
//	private static final long serialVersionUID = 1L;
	/**
	 * 
	 */
	private String[] places = {"1a","2a","3a","4a","1b","2b","3b","4b","1c","2c","3c","4c","1d","2d","3d","4d"};
	/**
	 * 
	 */
	private ArrayList<Rectangle> rectangles = new ArrayList<Rectangle>();
	/**
	 * 
	 */
	private ArrayList<String> places2 = new ArrayList<String>();
//	//private ArrayList<Person> people = new ArrayList<Person>();
//	private boolean print = true;
	/**
	 * 
	 */
	private float[] hsb = Color.RGBtoHSB(0, 255, 0, null);
//	private float change = (float) 0.1;
//	//private int tick = 0;
	/**
	 * 
	 */
	private Random rand = new Random();
	
	/**
	 * 
	 */
	private Timer timer = new Timer(1000,new ActionListener()
	{

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
//			if(Starter.tick%5==0){change= change*-1; print=true;}
//			
//			hsb[2]+=change;
//			Starter.tick++;
			
		}
		
	});
	
	/**
	 * 
	 */
	private Timer timer2 = new Timer(10,new ActionListener()
	{

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			
			repaint();
		}
		
	});
	
	/**
	 * 
	 */
	public AnimationPanel()
	{
		
		places= RandomizeArray(places);
		//set Initial Location
//		for (int i =0;i<places.length;i++)
//		{
//			Starter.people.get(rand.nextInt(Starter.people.size())).setPlace(rand.nextInt(places.length));
//		}
//		
//		for(int i =0;i<Starter.people.size();i++)
//		{
//			
//			Ellipse2D person = new Ellipse2D.Double(rand.nextInt(900),rand.nextInt(850),30,30);
//			Starter.people.get(i).setCircle(person);
//		}
		
		rectangles.add(new Rectangle(70, 30, 150, 150));
		rectangles.add(new Rectangle(250, 30, 150, 150));
		rectangles.add(new Rectangle(70, 240, 150, 150));
		rectangles.add(new Rectangle(250, 240, 150, 150));
		
		//Second Quadrant
		rectangles.add(new Rectangle(570, 30, 150, 150));
		rectangles.add(new Rectangle(750, 30, 150, 150));
		rectangles.add(new Rectangle(570, 240, 150, 150));
		rectangles.add(new Rectangle(750, 240, 150, 150));
		
		//Third Quadrant
		rectangles.add(new Rectangle(70, 505, 150, 150));
		rectangles.add(new Rectangle(250, 505, 150, 150));
		rectangles.add(new Rectangle(70, 715, 150, 150));
		rectangles.add(new Rectangle(250, 715, 150, 150));
		
		//Fourth Quadrant
		rectangles.add(new Rectangle(570, 505, 150, 150));
		rectangles.add(new Rectangle(750, 505, 150, 150));
		rectangles.add(new Rectangle(570, 715, 150, 150));
		rectangles.add(new Rectangle(750, 715, 150, 150));
		this.setBackground(Color.green);
		this.setPreferredSize(new Dimension(800,900));
		timer.start();
		timer2.start();
	//	this.setSize(800,900);
	}
	
	/**
	 * @param array
	 * @return
	 */
	private static String[] RandomizeArray(String[] array){
		Random rgen = new Random();  // Random number generator			
 
		for (int i=0; i<array.length; i++) {
		    int randomPosition = rgen.nextInt(array.length);
		    String temp = array[i];
		    array[i] = array[randomPosition];
		    array[randomPosition] = temp;
		}
 
		return array;
	}
	
	
	

	/* (non-Javadoc)
	 * @see javax.swing.JComponent#paintComponent(java.awt.Graphics)
	 */
	public void paintComponent(Graphics g)
	{
		Graphics2D g2 = (Graphics2D)g;
		super.paintComponent(g2);
		
		g2.setColor(Color.black);
		//Road
		Polygon p = new Polygon();
		
		this.setBackground(Color.getHSBColor(hsb[0], hsb[1], hsb[2]));
		p.addPoint(0, 425);
		p.addPoint(475, 425);
		p.addPoint(475,0);
		p.addPoint(525,0);
		p.addPoint(525,425);
		p.addPoint(950,425);
		p.addPoint(950,475);
		p.addPoint(525,475);
		p.addPoint(525,900);
		p.addPoint(475,900);
		p.addPoint(475,475);
		p.addPoint(0,475);
		p.addPoint(0,425);
		
		g2.fillPolygon(p);
		//g2.fillRect(0, 0, 100, 100);
		
		//First Quadrant
		g2.setColor(Color.white);
		
		
		
		for(int i=0;i<rectangles.size();i++)
		{
			g2.fill(rectangles.get(i)); 
		}
		
		g2.setColor(Color.black);
		
		for(int i =0;i<16;i++)
		{
			g2.drawString(places[i],rectangles.get(i).x+75,rectangles.get(i).y+75);
			places2.add(places[i]);
		}
		
		g2.setColor(Color.yellow);
		
		//Street Lines
		for(int i =0;i<5;i++)
		{
			g2.drawLine(10+i*90, 450, 75+i*90, 450);
			g2.drawLine(565+i*90, 450, 630+i*90, 450);
			g2.drawLine(500, 0+i*90, 500, 60+i*90);
			g2.drawLine(500, 480+i*90, 500, 540+i*90);
		}
		
		for(int i =0;i<Starter.people.size();i++)
		{
			
			if(!Starter.people.get(i).getCircle().intersects(rectangles.get(Starter.people.get(i).getPlace()))){
				g2.setColor(Starter.people.get(i).getGender());
			    g2.fill(Starter.people.get(i).getCircle());}
			
		}
		
		
	
	}
	
}
