package brains;

import java.awt.Color;
import java.awt.geom.Ellipse2D;
import java.util.Random;

/**
 * @author light
 *
 */
public class Person {
	
	/**
	 * 
	 */
	private int tick =0;
	

	/**
	 * 
	 */
	private int gender;
	/**
	 * 
	 */
	private int hairColor;
	/**
	 * 
	 */
	private int place;
	/**
	 * 
	 */
	private Ellipse2D circle;
	/**
	 * 
	 */
	private Random rand = new Random();
	
	
	
	/**
	 * 
	 */
	public Person()
	{
		setPlace(rand.nextInt(16));
		setCircle(new Ellipse2D.Double(rand.nextInt(900),rand.nextInt(850),30,30));
		setGender(rand.nextInt(2));
	}

	/**
	 * @return
	 */
	public Color getGender() {
		if(gender==0)
			return Color.BLUE;
		else
			return Color.red;
	}

	/**
	 * @param gender
	 */
	public void setGender(int gender) {
		this.gender = gender;
	}

	/**
	 * @return
	 */
	public int getHairColor() {
		return hairColor;
	}

	/**
	 * @param hairColor
	 */
	public void setHairColor(int hairColor) {
		this.hairColor = hairColor;
	}

	/**
	 * @return
	 */
	public int getPlace() {
		return place;
	}

	/**
	 * @param location
	 */
	public void setPlace(int location) {
		this.place = location;
	}
	/**
	 * @return
	 */
	public int getTick() {
		return tick;
	}

	/**
	 * @param tick
	 */
	public void setTick(int tick) {
		this.tick = tick;
	}
	/**
	 * @return
	 */
	public Ellipse2D getCircle() {
		return circle;
	}

	/**
	 * @param circle
	 */
	public void setCircle(Ellipse2D circle) {
		this.circle = circle;
	}
}
