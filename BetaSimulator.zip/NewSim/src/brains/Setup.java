package brains;

import java.io.BufferedReader;
import java.io.FileReader;

/**
 * @author light
 *
 */
public class Setup {
	/**
	 * 
	 */
	private int area;
	/**
	 * 
	 */
	private int female; 
	/**
	 * 
	 */
	private int male; 
	 
	/**
	 * 
	 */
	private int life; 
	/**
	 * 
	 */
	private int childLifeLen; 
	/**
	 * 
	 */
	private int adultLifeLen; 
	/**
	 * 
	 */
	private int oldLifeLen;  
	 
	/**
	 * 
	 */
	private double ChildRep1; 
	/**
	 * 
	 */
	private double ChildRep2; 
	/**
	 * 
	 */
	private double ChildRep3; 
	/**
	 * 
	 */
	private double ChildRep4;
	
	/**
	 * 
	 */
	private double AdultRep1; 
	/**
	 * 
	 */
	private double AdultRep2; 
	/**
	 * 
	 */
	private double AdultRep3; 
	/**
	 * 
	 */
	private double AdultRep4;
	
	/**
	 * 
	 */
	private double OldRep1;
	/**
	 * 
	 */
	private double OldRep2;
	
	/**
	 * 
	 */
	private double childDeathRate;
	/**
	 * 
	 */
	private double adultDeathRate;
	/**
	 * 
	 */
	private double oldDeathRate;
	
	/**
	 * 
	 */
	private double fatalDisPoss; 
	/**
	 * 
	 */
	private double fatalDisMin;
	/**
	 * 
	 */
	private double fatalDisMax;
	/**
	 * 
	 */
	private double fatalDisChildDeathRate;
	/**
	 * 
	 */
	private double fatalDisAdultDeathRate;
	/**
	 * 
	 */
	private double fatalDisOldDeathRate;
	
	
	/**
	 * 
	 */
	private double mildDisPoss;
	/**
	 * 
	 */
	private double mildDisMin;
	/**
	 * 
	 */
	private double mildDisMax;
	/**
	 * 
	 */
	private double mildDisChildDeathRate;
	/**
	 * 
	 */
	private double mildDisAdultDeathRate;
	/**
	 * 
	 */
	private double mildDisOldDeathRate;	
	 
	/**
	 * 
	 */
	private double dayWorkingChildren; 
	/**
	 * 
	 */
	private double dayWorkingAdults;
	/**
	 * 
	 */
	private double dayWorkingOld;
	/**
	 * 
	 */
	private double nightWorkingChildren;
	/**
	 * 
	 */
	private double nightWorkingAdult;
	/**
	 * 
	 */
	private double nightWorkingOld;
	
	/**
	 * 
	 */
	private double nonWorkingHome;
	/**
	 * 
	 */
	private double nonWorkingPlay;
	/**
	 * 
	 */
	private double nonWorkingSWE;
	 
	/**
	 * 
	 */
	private double playAfterWork;
	/**
	 * 
	 */
	private double sweAfterPlay; 
	/**
	 * 
	 */
	private double sweAfterWork; 
	/**
	 * 
	 */
	private double playAfterSWE; 
	 
	/**
	 * 
	 */
	private int nightTime; 
	/**
	 * 
	 */
	private int dayTime; 
	
	/**
	 * 
	 */
	private int workTime;
	/**
	 * 
	 */
	private int sweTime;
	/**
	 * 
	 */
	private int playTime;
	 
	/**
	 * 
	 */
	private int nightDur; 
	/**
	 * 
	 */
	private int dayDur; 
	 
	/**
	 * 
	 */
	private int startYear;
	/**
	 * 
	 */
	private int endYear;
	
	/**
	 * 
	 */
	public Setup()
	{
		try {
			FileReader fr = new FileReader("properties");
			BufferedReader br = new BufferedReader(fr);
			
			String temp="";
			
			while((temp= br.readLine())!=null)
			{
				if(temp.contains("Area")){area =Integer.parseInt(temp.split(":")[1].trim());}
				else if(temp.contains("Initial Female")){female =Integer.parseInt(temp.split(":")[1].trim());}
				else if(temp.contains("Initial Male")){male =Integer.parseInt(temp.split(":")[1].trim());}
				
				
				else if(temp.contains("Life Length")){life =Integer.parseInt(temp.split(":")[1].trim());}
				else if(temp.contains("Childhood Length")){childLifeLen =Integer.parseInt(temp.split(":")[1].trim());}
				else if(temp.contains("Adulthood Length")){adultLifeLen =Integer.parseInt(temp.split(":")[1].trim());}
				else if(temp.contains("Old-hood Length")){oldLifeLen =Integer.parseInt(temp.split(":")[1].trim());}
				
				
				else if(temp.contains("Childhood Reproduction1")){ChildRep1 =Double.parseDouble(temp.split(":")[1].split(" ")[1])*Double.parseDouble(temp.split(":")[1].split(" ")[2]);}
				else if(temp.contains("Childhood Reproduction 2")){ChildRep2 =Double.parseDouble(temp.split(":")[1].split(" ")[1])*Double.parseDouble(temp.split(":")[1].split(" ")[2]);}
				else if(temp.contains("Childhood Reproduction 3")){ChildRep3 =Double.parseDouble(temp.split(":")[1].split(" ")[1])*Double.parseDouble(temp.split(":")[1].split(" ")[2]);}
				else if(temp.contains("Childhood Reproduction 4")){ChildRep4 =Double.parseDouble(temp.split(":")[1].split(" ")[1])*Double.parseDouble(temp.split(":")[1].split(" ")[2]);}
				
				
				else if(temp.contains("Adulthood Reproduction1")){AdultRep1 =Double.parseDouble(temp.split(":")[1].split(" ")[1])*Double.parseDouble(temp.split(":")[1].split(" ")[2]);}
				else if(temp.contains("Adulthood Reproduction 2")){AdultRep2 =Double.parseDouble(temp.split(":")[1].split(" ")[1])*Double.parseDouble(temp.split(":")[1].split(" ")[2]);}
				else if(temp.contains("Adulthood Reproduction 3")){AdultRep3 =Double.parseDouble(temp.split(":")[1].split(" ")[1])*Double.parseDouble(temp.split(":")[1].split(" ")[2]);}
				
				
				else if(temp.contains("Oldhood Reproduction1")){OldRep1 =Double.parseDouble(temp.split(":")[1].split(" ")[1])*Double.parseDouble(temp.split(":")[1].split(" ")[2]);}
				else if(temp.contains("Oldhood Reproduction 2")){OldRep2 =Double.parseDouble(temp.split(":")[1].split(" ")[1])*Double.parseDouble(temp.split(":")[1].split(" ")[2]);}
				
				else if(temp.contains("Childhood Death Rate")){childDeathRate =Double.parseDouble(temp.split(":")[1]);}
				else if(temp.contains("Adulthood Death Rate")){adultDeathRate =Double.parseDouble(temp.split(":")[1]);}
				else if(temp.contains("Oldhood Death Rate")){oldDeathRate =Double.parseDouble(temp.split(":")[1]);}
				
				
				
				else if(temp.contains("Fatal Disaster Possibility")){fatalDisPoss =Double.parseDouble(temp.split(":")[1].trim());}
				else if(temp.contains("Fatal Disaster minimum every")){fatalDisMin =Double.parseDouble(temp.split(":")[1].trim());}
				else if(temp.contains("Fatal Disaster maximum every")){fatalDisMax =Double.parseDouble(temp.split(":")[1].trim());}
				else if(temp.contains("Fatal Disaster Children Death Rate")){fatalDisChildDeathRate =Double.parseDouble(temp.split(":")[1].trim());}
				else if(temp.contains("Fatal Disaster Adults Death Rate")){fatalDisAdultDeathRate =Double.parseDouble(temp.split(":")[1].trim());}
				else if(temp.contains("Fatal Disaster Elderly Death Rate")){fatalDisOldDeathRate =Double.parseDouble(temp.split(":")[1].trim());}
				
				
				else if(temp.contains("Mild Disaster Possibility")){mildDisPoss =Double.parseDouble(temp.split(":")[1].trim());}
				else if(temp.contains("Mild Disaster minimum every")){mildDisMin =Double.parseDouble(temp.split(":")[1].trim());}
				else if(temp.contains("Mild Disaster maximum every")){mildDisMax =Double.parseDouble(temp.split(":")[1].trim());}
				else if(temp.contains("Mild Disaster Children Death Rate")){mildDisChildDeathRate =Double.parseDouble(temp.split(":")[1].trim());}
				else if(temp.contains("Mild Disaster Adults Death Rate")){mildDisAdultDeathRate =Double.parseDouble(temp.split(":")[1].trim());}
				else if(temp.contains("Mild Disaster Elderly Death Rate")){mildDisOldDeathRate =Double.parseDouble(temp.split(":")[1].trim());}
				
				
				else if(temp.contains("Day Working Children")){dayWorkingChildren =Double.parseDouble(temp.split(":")[1].trim());}
				else if(temp.contains("Day Working Adults")){dayWorkingAdults =Double.parseDouble(temp.split(":")[1].trim());}
				else if(temp.contains("Day Working Elderly")){dayWorkingOld =Double.parseDouble(temp.split(":")[1].trim());}
				else if(temp.contains("Night Working Children")){nightWorkingChildren =Double.parseDouble(temp.split(":")[1].trim());}
				else if(temp.contains("Night Working Adults")){nightWorkingAdult =Double.parseDouble(temp.split(":")[1].trim());}
				else if(temp.contains("Night Working Elderly")){nightWorkingOld =Double.parseDouble(temp.split(":")[1].trim());}
				
				
				else if(temp.contains("Non Workers at Home")){nonWorkingHome =Double.parseDouble(temp.split(":")[1].trim());}
				else if(temp.contains("Non Workers at Play")){nonWorkingPlay =Double.parseDouble(temp.split(":")[1].trim());}
				else if(temp.contains("Non Worker at Somewhere Else")){nonWorkingSWE =Double.parseDouble(temp.split(":")[1].trim());}
				
				
				else if(temp.contains("Playing after Working")){playAfterWork =Double.parseDouble(temp.split(":")[1].trim());}
				else if(temp.contains("Somewhere else after Playing")){sweAfterPlay =Double.parseDouble(temp.split(":")[1].trim());}
				else if(temp.contains("Somewhere else after Working")){sweAfterWork =Double.parseDouble(temp.split(":")[1].trim());}
				else if(temp.contains("Playing after Somewhere else")){playAfterSWE =Double.parseDouble(temp.split(":")[1].trim());}
				
				
				else if(temp.contains("Night Time")){nightTime =Integer.parseInt(temp.split(":")[1].split(" ")[1]);}
				else if(temp.contains("Day Time")){dayTime =Integer.parseInt(temp.split(":")[1].split(" ")[1]);}
				
				
				else if(temp.contains("Working Time")){workTime =Integer.parseInt(temp.split(":")[1].split(" ")[1]);}
				else if(temp.contains("SWE Time")){sweTime =Integer.parseInt(temp.split(":")[1].split(" ")[1]);}
				else if(temp.contains("Playing Time")){playTime =Integer.parseInt(temp.split(":")[1].split(" ")[1]);}
				
				
				else if(temp.contains("Night duration")){nightDur =Integer.parseInt(temp.split(":")[1].split(" ")[1]);}
				else if(temp.contains("Day duration")){dayDur =Integer.parseInt(temp.split(":")[1].split(" ")[1]);}
				
				
				else if(temp.contains("Starting Year")){startYear =Integer.parseInt(temp.split(":")[1].trim());}
				else if(temp.contains("End Year")){endYear =Integer.parseInt(temp.split(":")[1].trim());}
				
			}
			
			br.close();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @return
	 */
	public int getArea() {
		return area;
	}

	/**
	 * @param area
	 */
	public void setArea(int area) {
		this.area = area;
	}

	/**
	 * @return
	 */
	public int getFemale() {
		return female;
	}

	/**
	 * @param female
	 */
	public void setFemale(int female) {
		this.female = female;
	}

	/**
	 * @return
	 */
	public int getMale() {
		return male;
	}

	/**
	 * @param male
	 */
	public void setMale(int male) {
		this.male = male;
	}

	/**
	 * @return
	 */
	public int getLife() {
		return life;
	}

	/**
	 * @param life
	 */
	public void setLife(int life) {
		this.life = life;
	}

	/**
	 * @return
	 */
	public int getChildLifeLen() {
		return childLifeLen;
	}

	/**
	 * @param childLifeLen
	 */
	public void setChildLifeLen(int childLifeLen) {
		this.childLifeLen = childLifeLen;
	}

	/**
	 * @return
	 */
	public int getAdultLifeLen() {
		return adultLifeLen;
	}

	/**
	 * @param adultLifeLen
	 */
	public void setAdultLifeLen(int adultLifeLen) {
		this.adultLifeLen = adultLifeLen;
	}

	/**
	 * @return
	 */
	public int getOldLifeLen() {
		return oldLifeLen;
	}

	/**
	 * @param oldLifeLen
	 */
	public void setOldLifeLen(int oldLifeLen) {
		this.oldLifeLen = oldLifeLen;
	}

	/**
	 * @return
	 */
	public double getChildRep1() {
		return ChildRep1;
	}

	/**
	 * @param childRep1
	 */
	public void setChildRep1(double childRep1) {
		ChildRep1 = childRep1;
	}

	/**
	 * @return
	 */
	public double getChildRep2() {
		return ChildRep2;
	}

	/**
	 * @param childRep2
	 */
	public void setChildRep2(double childRep2) {
		ChildRep2 = childRep2;
	}

	/**
	 * @return
	 */
	public double getChildRep3() {
		return ChildRep3;
	}

	/**
	 * @param childRep3
	 */
	public void setChildRep3(double childRep3) {
		ChildRep3 = childRep3;
	}

	/**
	 * @return
	 */
	public double getChildRep4() {
		return ChildRep4;
	}

	/**
	 * @param childRep4
	 */
	public void setChildRep4(double childRep4) {
		ChildRep4 = childRep4;
	}

	/**
	 * @return
	 */
	public double getAdultRep1() {
		return AdultRep1;
	}

	/**
	 * @param adultRep1
	 */
	public void setAdultRep1(double adultRep1) {
		AdultRep1 = adultRep1;
	}

	/**
	 * @return
	 */
	public double getAdultRep2() {
		return AdultRep2;
	}

	/**
	 * @param adultRep2
	 */
	public void setAdultRep2(double adultRep2) {
		AdultRep2 = adultRep2;
	}

	/**
	 * @return
	 */
	public double getAdultRep3() {
		return AdultRep3;
	}

	/**
	 * @param adultRep3
	 */
	public void setAdultRep3(double adultRep3) {
		AdultRep3 = adultRep3;
	}

	/**
	 * @return
	 */
	public double getAdultRep4() {
		return AdultRep4;
	}

	/**
	 * @param adultRep4
	 */
	public void setAdultRep4(double adultRep4) {
		AdultRep4 = adultRep4;
	}

	/**
	 * @return
	 */
	public double getOldRep1() {
		return OldRep1;
	}

	/**
	 * @param oldRep1
	 */
	public void setOldRep1(double oldRep1) {
		OldRep1 = oldRep1;
	}

	/**
	 * @return
	 */
	public double getOldRep2() {
		return OldRep2;
	}

	/**
	 * @param oldRep2
	 */
	public void setOldRep2(double oldRep2) {
		OldRep2 = oldRep2;
	}

	/**
	 * @return
	 */
	public double getChildDeathRate() {
		return childDeathRate;
	}

	/**
	 * @param childDeathRate
	 */
	public void setChildDeathRate(double childDeathRate) {
		this.childDeathRate = childDeathRate;
	}

	/**
	 * @return
	 */
	public double getAdultDeathRate() {
		return adultDeathRate;
	}

	/**
	 * @param adultDeathRate
	 */
	public void setAdultDeathRate(double adultDeathRate) {
		this.adultDeathRate = adultDeathRate;
	}

	/**
	 * @return
	 */
	public double getOldDeathRate() {
		return oldDeathRate;
	}

	/**
	 * @param oldDeathRate
	 */
	public void setOldDeathRate(double oldDeathRate) {
		this.oldDeathRate = oldDeathRate;
	}

	/**
	 * @return
	 */
	public double getFatalDisPoss() {
		return fatalDisPoss;
	}

	/**
	 * @param fatalDisPoss
	 */
	public void setFatalDisPoss(double fatalDisPoss) {
		this.fatalDisPoss = fatalDisPoss;
	}

	/**
	 * @return
	 */
	public double getFatalDisMin() {
		return fatalDisMin;
	}

	/**
	 * @param fatalDisMin
	 */
	public void setFatalDisMin(double fatalDisMin) {
		this.fatalDisMin = fatalDisMin;
	}

	/**
	 * @return
	 */
	public double getFatalDisMax() {
		return fatalDisMax;
	}

	/**
	 * @param fatalDisMax
	 */
	public void setFatalDisMax(double fatalDisMax) {
		this.fatalDisMax = fatalDisMax;
	}

	/**
	 * @return
	 */
	public double getFatalDisChildDeathRate() {
		return fatalDisChildDeathRate;
	}

	/**
	 * @param fatalDisChildDeathRate
	 */
	public void setFatalDisChildDeathRate(double fatalDisChildDeathRate) {
		this.fatalDisChildDeathRate = fatalDisChildDeathRate;
	}

	/**
	 * @return
	 */
	public double getFatalDisAdultDeathRate() {
		return fatalDisAdultDeathRate;
	}

	/**
	 * @param fatalDisAdultDeathRate
	 */
	public void setFatalDisAdultDeathRate(double fatalDisAdultDeathRate) {
		this.fatalDisAdultDeathRate = fatalDisAdultDeathRate;
	}

	/**
	 * @return
	 */
	public double getFatalDisOldDeathRate() {
		return fatalDisOldDeathRate;
	}

	/**
	 * @param fatalDisOldDeathRate
	 */
	public void setFatalDisOldDeathRate(double fatalDisOldDeathRate) {
		this.fatalDisOldDeathRate = fatalDisOldDeathRate;
	}

	/**
	 * @return
	 */
	public double getMildDisPoss() {
		return mildDisPoss;
	}

	/**
	 * @param mildDisPoss
	 */
	public void setMildDisPoss(double mildDisPoss) {
		this.mildDisPoss = mildDisPoss;
	}

	/**
	 * @return
	 */
	public double getMildDisMin() {
		return mildDisMin;
	}

	/**
	 * @param mildDisMin
	 */
	public void setMildDisMin(double mildDisMin) {
		this.mildDisMin = mildDisMin;
	}

	/**
	 * @return
	 */
	public double getMildDisMax() {
		return mildDisMax;
	}

	/**
	 * @param mildDisMax
	 */
	public void setMildDisMax(double mildDisMax) {
		this.mildDisMax = mildDisMax;
	}

	/**
	 * @return
	 */
	public double getMildDisChildDeathRate() {
		return mildDisChildDeathRate;
	}

	/**
	 * @param mildDisChildDeathRate
	 */
	public void setMildDisChildDeathRate(double mildDisChildDeathRate) {
		this.mildDisChildDeathRate = mildDisChildDeathRate;
	}

	/**
	 * @return
	 */
	public double getMildDisAdultDeathRate() {
		return mildDisAdultDeathRate;
	}

	/**
	 * @param mildDisAdultDeathRate
	 */
	public void setMildDisAdultDeathRate(double mildDisAdultDeathRate) {
		this.mildDisAdultDeathRate = mildDisAdultDeathRate;
	}

	/**
	 * @return
	 */
	public double getMildDisOldDeathRate() {
		return mildDisOldDeathRate;
	}

	/**
	 * @param mildDisOldDeathRate
	 */
	public void setMildDisOldDeathRate(double mildDisOldDeathRate) {
		this.mildDisOldDeathRate = mildDisOldDeathRate;
	}

	/**
	 * @return
	 */
	public double getDayWorkingChildren() {
		return dayWorkingChildren;
	}

	/**
	 * @param dayWorkingChildren
	 */
	public void setDayWorkingChildren(double dayWorkingChildren) {
		this.dayWorkingChildren = dayWorkingChildren;
	}

	/**
	 * @return
	 */
	public double getDayWorkingAdults() {
		return dayWorkingAdults;
	}

	/**
	 * @param dayWorkingAdults
	 */
	public void setDayWorkingAdults(double dayWorkingAdults) {
		this.dayWorkingAdults = dayWorkingAdults;
	}

	/**
	 * @return
	 */
	public double getDayWorkingOld() {
		return dayWorkingOld;
	}

	/**
	 * @param dayWorkingOld
	 */
	public void setDayWorkingOld(double dayWorkingOld) {
		this.dayWorkingOld = dayWorkingOld;
	}

	/**
	 * @return
	 */
	public double getNightWorkingChildren() {
		return nightWorkingChildren;
	}

	/**
	 * @param nightWorkingChildren
	 */
	public void setNightWorkingChildren(double nightWorkingChildren) {
		this.nightWorkingChildren = nightWorkingChildren;
	}

	/**
	 * @return
	 */
	public double getNightWorkingAdult() {
		return nightWorkingAdult;
	}

	/**
	 * @param nightWorkingAdult
	 */
	public void setNightWorkingAdult(double nightWorkingAdult) {
		this.nightWorkingAdult = nightWorkingAdult;
	}

	/**
	 * @return
	 */
	public double getNightWorkingOld() {
		return nightWorkingOld;
	}

	/**
	 * @param nightWorkingOld
	 */
	public void setNightWorkingOld(double nightWorkingOld) {
		this.nightWorkingOld = nightWorkingOld;
	}

	/**
	 * @return
	 */
	public double getNonWorkingHome() {
		return nonWorkingHome;
	}

	/**
	 * @param nonWorkingHome
	 */
	public void setNonWorkingHome(double nonWorkingHome) {
		this.nonWorkingHome = nonWorkingHome;
	}

	/**
	 * @return
	 */
	public double getNonWorkingPlay() {
		return nonWorkingPlay;
	}

	/**
	 * @param nonWorkingPlay
	 */
	public void setNonWorkingPlay(double nonWorkingPlay) {
		this.nonWorkingPlay = nonWorkingPlay;
	}

	/**
	 * @return
	 */
	public double getNonWorkingSWE() {
		return nonWorkingSWE;
	}

	/**
	 * @param nonWorkingSWE
	 */
	public void setNonWorkingSWE(double nonWorkingSWE) {
		this.nonWorkingSWE = nonWorkingSWE;
	}

	/**
	 * @return
	 */
	public double getPlayAfterWork() {
		return playAfterWork;
	}

	/**
	 * @param playAfterWork
	 */
	public void setPlayAfterWork(double playAfterWork) {
		this.playAfterWork = playAfterWork;
	}

	/**
	 * @return
	 */
	public double getSweAfterPlay() {
		return sweAfterPlay;
	}

	/**
	 * @param sweAfterPlay
	 */
	public void setSweAfterPlay(double sweAfterPlay) {
		this.sweAfterPlay = sweAfterPlay;
	}

	/**
	 * @return
	 */
	public double getSweAfterWork() {
		return sweAfterWork;
	}

	/**
	 * @param sweAfterWork
	 */
	public void setSweAfterWork(double sweAfterWork) {
		this.sweAfterWork = sweAfterWork;
	}

	/**
	 * @return
	 */
	public double getPlayAfterSWE() {
		return playAfterSWE;
	}

	/**
	 * @param playAfterSWE
	 */
	public void setPlayAfterSWE(double playAfterSWE) {
		this.playAfterSWE = playAfterSWE;
	}

	/**
	 * @return
	 */
	public int getNightTime() {
		return nightTime;
	}

	/**
	 * @param nightTime
	 */
	public void setNightTime(int nightTime) {
		this.nightTime = nightTime;
	}

	/**
	 * @return
	 */
	public int getDayTime() {
		return dayTime;
	}

	/**
	 * @param dayTime
	 */
	public void setDayTime(int dayTime) {
		this.dayTime = dayTime;
	}

	/**
	 * @return
	 */
	public int getWorkTime() {
		return workTime;
	}

	/**
	 * @param workTime
	 */
	public void setWorkTime(int workTime) {
		this.workTime = workTime;
	}

	/**
	 * @return
	 */
	public int getSweTime() {
		return sweTime;
	}

	/**
	 * @param sweTime
	 */
	public void setSweTime(int sweTime) {
		this.sweTime = sweTime;
	}

	/**
	 * @return
	 */
	public int getPlayTime() {
		return playTime;
	}

	/**
	 * @param playTime
	 */
	public void setPlayTime(int playTime) {
		this.playTime = playTime;
	}

	/**
	 * @return
	 */
	public int getNightDur() {
		return nightDur;
	}

	/**
	 * @param nightDur
	 */
	public void setNightDur(int nightDur) {
		this.nightDur = nightDur;
	}

	/**
	 * @return
	 */
	public int getDayDur() {
		return dayDur;
	}

	/**
	 * @param dayDur
	 */
	public void setDayDur(int dayDur) {
		this.dayDur = dayDur;
	}

	/**
	 * @return
	 */
	public int getStartYear() {
		return startYear;
	}

	/**
	 * @param startYear
	 */
	public void setStartYear(int startYear) {
		this.startYear = startYear;
	}

	/**
	 * @return
	 */
	public int getEndYear() {
		return endYear;
	}

	/**
	 * @param endYear
	 */
	public void setEndYear(int endYear) {
		this.endYear = endYear;
	}
	
	
	
}
