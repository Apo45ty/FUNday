package brains;

import java.util.Random;
import java.util.TimerTask;

import brawns.Starter;

/**
 * @author light
 *
 */
public class Task extends TimerTask {

	/**
	 * 
	 */
	Random rand = new Random();
	/**
	 * 
	 */
	Setup set = new Setup();
	/* (non-Javadoc)
	 * @see java.util.TimerTask#run()
	 */
	@Override
	public void run() {
	//Children
		if(Starter.tick%set.getChildLifeLen()==0&&Starter.tick!=0)
		{
			int kids = (int)(set.getChildRep1()*Starter.people.size()+set.getChildRep2()*Starter.people.size()+set.getChildRep3()*Starter.people.size()+set.getChildRep4()*Starter.people.size());
			int tempDeaths = (int) (Starter.people.size()*set.getChildDeathRate());
			
			for(int i=0;i<tempDeaths;i++)
			{	
				Starter.people.remove(rand.nextInt(Starter.people.size()));
			}
			for(int i =0; i<kids;i++)
			{
				Starter.people.add(new Person());
			}
			
			System.out.println("this happened");
		}
		System.out.println(Starter.people.size());
		Starter.tick++;
	}

}
